package com.mypack.entity;




import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;


@Entity
@Table(name="task")
public class Task {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	
	@NotBlank(message = "Task Name is mandatory")
    @Column(name = "task_name")
    private String taskName;
	
	@NotBlank(message = "Description is mandatory")
    @Column(name = "description")
	private String description;
	
	@Column(name = "status")
	private String status;
	
	 @Column(name = "target_date")
	 @DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date targetDate;
	 
	 
	 public Task() {}

	public Task(long id, @NotBlank(message = "Task Name is mandatory") String taskName,
			@NotBlank(message = "Description is mandatory") String description, String status, Date targetDate) {
		
		this.id = id;
		this.taskName = taskName;
		this.description = description;
		this.status = status;
		this.targetDate = targetDate;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getTaskName() {
		return taskName;
	}

	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getTargetDate() {
		return targetDate;
	}

	public void setTargetDate(Date targetDate) {
		this.targetDate = targetDate;
	}
	
	 
}
